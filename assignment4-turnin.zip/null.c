#include <stdio.h>

int main()
{
	int* zero = NULL;
	return *zero;
}
